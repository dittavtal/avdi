If you need PSD templates of the theme, register as a client in our support panel and send us a ticket. 
Archive with PSD's will be share on Dropbox to your email.

PSD's is quite huge (~100 Mb), so we do not include it into archive with theme directly.

Please visit and send your email address: http://secretlab.pw/helpdesk/signup.php